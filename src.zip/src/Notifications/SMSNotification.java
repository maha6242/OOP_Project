package Notifications;

public class SMSNotification {
}