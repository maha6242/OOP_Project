/**
 * 
 */
/**
 * 
 */
module project2 {
	requires java.desktop;
	requires javafx.graphics;
	requires jakarta.mail;
	requires jakarta.activation;
	requires javafx.controls;
	requires javafx.fxml;
	requires java.sql;
	exports com.hamza6dev.oopsieeee;
}